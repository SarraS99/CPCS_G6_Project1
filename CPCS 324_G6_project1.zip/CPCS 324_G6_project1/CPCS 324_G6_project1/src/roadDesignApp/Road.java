/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roadDesignApp;

import GraphFrameWork.Edge;
import GraphFrameWork.Vertex;

/**
 *
 * @author maha2
 */
public class Road extends Edge {

    int Roadsize;
    

    public Road(Vertex Source, Vertex Target, int weight) {
        super(Source, Target, weight);
    }

    @Override
    public void displayInfo() {
        super.displayInfo(); 
    }

}
