/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roadDesignApp;

import GraphFrameWork.Vertex;

/**
 *
 * @author maha2
 */
public class House extends Vertex {

    String HouseName;

    public House(int label, boolean isVisited) {
        super(label);
    }

    @Override
    public void displayInfo() {
        super.displayInfo(); 
    }

}
