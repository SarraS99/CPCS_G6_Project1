/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roadDesignApp;

import GraphFrameWork.KruskalAlg;
import GraphFrameWork.PQPrimAlg;
import GraphFrameWork.graph;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author maha2
 */
public class RoadDesignApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        Scanner input = new Scanner(System.in);

        graph g = new graph();
        int choice = 0;
        int Algo = 0;
        while (choice != 3) {
            System.out.println("");
            System.out.println("------------------------------------------------------------------");
            System.out.println("                     CPCS324 Project Phase 1  ");
            System.out.println("------------------------------------------------------------------");
            System.out.println("Choose one of the following options: ");
            System.out.println(" 1- Read the graph vertecies and edges from the file. ");
            System.out.println(" 2- Choose a specific number of vertecies and edges. ");
            System.out.println(" 3- End the program. ");
            System.out.print("Enter your choice: ");
            choice = input.nextInt();

            if (choice == 1) {

                File myFile = new File("file.txt");
                //call the method to read from file
                g.readGraphFromFile(myFile);
                System.out.println("----------------------------------------------------------------\n");
                System.out.println("Choose one of the following Algorithm: ");
                System.out.println("----------------------------------------------------------------\n");

                System.out.println("1- Kruskal's Algorithm ");
                System.out.println("2- Prim's Algorithm based on Priority Queue");
                System.out.print("Enter your choice: ");
                Algo = input.nextInt();
                System.out.println("");

                if (Algo == 1) {
                    KruskalAlg k = new KruskalAlg(g);
                    k.displayResultingMST(g, choice);

                    // if the user choose the second choice 
                } else if (Algo == 2) {

                    PQPrimAlg q = new PQPrimAlg(g);
                    q.displayResultingMST(g, choice);
                    //else if the user enter wrong choice
                } else {
                    System.out.println("you entered wrong choice try again ");
                }

            } else if (choice == 2) {
                System.out.println("----------------------------------------------------------------\n");
                System.out.println("Enter  0 if it is an undirected graph and 1 if it is digraph");
                int isd = input.nextInt();
                System.out.println("----------------------------------------------------------------\n");

                System.out.println("choose one of the following list to print the result for it: ");
                System.out.println("n is the number of vertecies and m is the number of edges ");
                System.out.println("1- n=1000 , m=10000");
                System.out.println("2- n=1000 , m=15000");
                System.out.println("3- n=1000 , m=25000");
                System.out.println("4- n=5000 , m=15000");
                System.out.println("5- n=5000 , m=25000");
                System.out.println("6- n=10000 , m=15000");
                System.out.println("7- n=10000 , m=25000");
                System.out.println("");
                System.out.println("Enter Your Choice: ");
                // reading the choice from user 
                int choice2 = input.nextInt();

                switch (choice2) {
                    case 1:
                        g = new graph(1000, 10000, isd);
                        break;
                    case 2:
                        g = new graph(1000, 15000, isd);
                        break;
                    case 3:
                        g = new graph(1000, 25000, isd);
                        break;
                    case 4:
                        g = new graph(5000, 15000, isd);
                        break;
                    case 5:
                        g = new graph(5000, 25000, isd);
                        break;
                    case 6:
                        g = new graph(10000, 15000, isd);
                        break;
                    case 7:
                        g = new graph(10000, 25000, isd);
                        break;
                    default:
                        System.out.println("you entered wrong choice try again ");

                }// end switch  

                // printing the algorithms to the user to choose one 
                System.out.println("1- Kruskal's Algorithm ");
                System.out.println("2- Prim's Algorithm based on Priority Queue ");
                System.out.println("");
                System.out.println("Enter Your Choice: ");
                // reading the choice of the algorithm from user 
                Algo = input.nextInt();

                if (Algo == 1) {

                    KruskalAlg k = new KruskalAlg(g);
                    k.displayResultingMST(g, choice);
                } else if (Algo == 2) {

                    PQPrimAlg q = new PQPrimAlg(g);
                    q.displayResultingMST(g, choice);
                } else {
                    System.out.println("you entered wrong choice try again ");
                }

            }

        }

        input.close();
    }

}
