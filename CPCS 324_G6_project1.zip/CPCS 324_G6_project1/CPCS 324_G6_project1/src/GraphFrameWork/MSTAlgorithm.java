
package GraphFrameWork;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 *
 * @author maha2
 */
public class MSTAlgorithm {
    LinkedList<Edge> MSTresultList;

    long ExcutionTime;

     graph Graph;
//======================================
    
    
    
    public graph getGraph() {
        return Graph;
    }

    public void setGraph(graph g) {
        this.Graph = g;
    }

    public  MSTAlgorithm(graph graph) {
        this.Graph = graph;
        MSTresultList = new LinkedList<>();
    }

    public LinkedList<Edge> getMSTresultList() {
        return MSTresultList;
    }

    public void setMSTresultList(LinkedList<Edge> MSTresultList) {
        this.MSTresultList = MSTresultList;
    }

    public long getExcutionTime() {
        return ExcutionTime;
    }




            
}
