/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GraphFrameWork;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
/**
 *
 * @author maha2
 */
public class graph {

    private int verticesNo;

    private int edgeNo=0;

    private boolean isDigraph = false;

     Vertex[] vertices;
    
    private  LinkedList<Edge> edge;
    
    

    //=============================================
    public graph() {
         
    }

   
    public graph(int verticesNo, int edgeNo, int isD) {
        this.verticesNo = verticesNo;
        this.vertices = new Vertex[verticesNo];
        this.edge = new LinkedList <Edge>();
        if ( isD == 1 ) {
            this.isDigraph = true;
        }      
        makeGraph(verticesNo,edgeNo,isD);
    }
    

// creating a graph object with the specified parameters
    public void makeGraph(int verticesNo, int edges, int isd) {
 
        int remainEdges = edges;

        //a loop to create vertices
        for (int i = 0; i < verticesNo ; i++) {
            
            Vertex v = new Vertex(i, false);
           
            vertices[i] = v;
        }

        //creating edges 
        // *it has to connects the created vertices randomly 
        // *first we will connect the all vertices with each other 
        // * then well conntect the first and last vertex
        for (int i = 0; i < verticesNo ; i++) {
            
            //the weight is randomly generated
            int wt = (int) (Math.random() * 500);
              
            if (isDigraph) {
                //the first and last vertex 
                if (i == verticesNo - 1) {
                    addEdge(vertices[verticesNo - 1], vertices[0], wt);
                } else {
                    addEdge(vertices[i], vertices[i + 1], wt);
                }

            }//end directed 
           
              //if not directed 
              if (!isDigraph) {
                //the first and last vertex  
                if (i == verticesNo - 1) {
                    
                    Edge ee = new Edge(vertices[verticesNo - 1], vertices[0], wt);
                    addEdge(vertices[verticesNo - 1], vertices[0], wt);
                    addEdge(vertices[0], vertices[verticesNo - 1], wt);
                    //add the edge to the list of the edges 
                    edge.add(ee);
                    edgeNo++;
                } else {
                    //connecting source with target and target with source 
                    Edge e = new Edge(vertices[i], vertices[i + 1], wt);
                    addEdge(vertices[i], vertices[i + 1], wt);
                    addEdge(this.vertices[i + 1], this.vertices[i], wt);
                    //add the edge to the list of the edges 
                    edge.add(e);
                    edgeNo++;

                }
            }
        }//End for 
          
               
        // now we have made sure the graph is connected we have to make sure the edges are 
        //the spesifed number and random  
        for (; edgeNo < remainEdges; ) {
          
            int source = (int) (Math.random() * verticesNo);
            int target = (int) (Math.random() * verticesNo);
            if (target == source) {
                continue;
            }
            if (CheckEdge(source, target, edge)) {
                 continue;
            }
              //the weight is randomly generated
             int wt = (int) (Math.random() * 500);
             //when the graph is digraph then one edge and when not 2
             if (isDigraph) {
                addEdge(vertices[source], vertices[target], wt);
            }
             if (!isDigraph) { 
                 Edge ee = new Edge (vertices[source],vertices[target],wt);
                 addEdge(vertices[source], vertices[target], wt);
                 addEdge(vertices[target], vertices[source], wt);
                  edge.add(ee);
                  edgeNo++;
            }
             
        }//end for 
       
    }
    
//----------------------------------------------------------------------------------------------
    
//function to add the edges to the source and target verteces 
    public void addEdge(Vertex Source, Vertex Target, int w) {
        // if directed 
        if (isDigraph) {
         Edge e = new Edge(Source, Target,w);
        vertices[Source.label].getAdjList().addLast(e);       
       //add the edge to the list of the edges 
        edge.add(e);
        edgeNo++;
        }
          // if undirected
        if (isDigraph == false) { 
        Edge e2 = new Edge(Source,Target,w);
        vertices[Source.label].getAdjList().addLast(e2);
        } 
    }// End function
    //function to check if the randomly generated edges exists
    public boolean CheckEdge(int src, int trgt, LinkedList<Edge> edgeslist) {
        for (int i = 0; i < edgeslist.size(); i++) {
            Edge temp = edgeslist.get(i);
            //if directed 
            if (isDigraph) {
                if (temp.Target.label == trgt && temp.Source.label == src) {
                    return true;
                }
            }
            //if not 
            if (!isDigraph) {
                if (temp.Target.label == trgt && temp.Source.label == src || temp.Target.label == src && temp.Source.label == trgt) {
                    return true;
                }
            }
        }//end for

        return false;
    }
    // function for the read form file function
    public Edge addEdge2 (Vertex Source, Vertex Target, int w){
        if (isDigraph) {
             if (vertices[Source.label] == null) {
            vertices[Source.label] = Source;
        }
        if (vertices[Target.label] == null) {
            vertices[Target.label] = Target;
        }
        Edge e = new Edge(Source, Target, w);
        vertices[Source.label].getAdjList().addLast(e);
        //add the edge to the list of the edges 
        edge.add(e);
        }           
        // if undirected
        if ( isDigraph == false) {   
              if(vertices[Source.label] == null) {
            vertices[Source.label] = Source;
        }
        if (vertices[Target.label] == null) {
            vertices[Target.label] = Target;
        }
           Edge e2 = new Edge(Source, Target, w);
           Edge e = new Edge(Target, Source, w);
            vertices[Source.getLabel()].getAdjList().add(e2);
            vertices[Target.label].getAdjList().addLast(e);
            edge.add(e2);
            return e;
        }
        return null;

    }
    
    
    public void readGraphFromFile(File file) throws FileNotFoundException {
       this.edge = new LinkedList <Edge>();
        Scanner read = new Scanner(file);

        //reading the first number to know if the graph is directed or not
        read.next();
        int diagraph = Integer.parseInt(read.next());
        
        if (diagraph == 0) {
            this.setIsDigraph(false);
        }//end if 
        else {
            this.setIsDigraph(true);
        }//end else 
 
        // reading the number of vertex 
        int v = read.nextInt();
        this.setVerticesNo(v);
        
        // reading the number of edges 
        int e = read.nextInt();
        this.setEdgeNo(e);
        
        // declare and cerate the array for list of vertices 
        vertices = new Vertex [verticesNo];          
        
        //while loop to read the graph from the file 
        while (read.hasNext()) {
            // reading the source , the target , and the weight 
            char source = read.next().charAt(0);
            char target = read.next().charAt(0);
            int w = Integer.parseInt(read.next());
            
           // System.out.println("src = " + source + " targ = " + target + " weight "+ w);
            
            Vertex src = new Vertex(source);
            Vertex targ = new Vertex(target);
            
            // variables to save the position of the vertecies 
              // set the label of the source vertex
            src.label = source - 'A';
                 // set the label of the target vertex
            targ.label = target - 'A';
            
            //calling add edge function to create the edge 
            Edge edge = addEdge2(src, targ,w);
   
          }//end while 
        
        
        read.close();
   }
  
    public void setVerticesNo(int verticesNo) {
        this.verticesNo = verticesNo;
    }

    public Vertex[] getVertices() {
        return this.vertices;
    }

    public void setVertices(Vertex[] vertices) {
        this.vertices = vertices;
    }

   

    public int getVerticesNo() {
        return verticesNo;
    }

    public void setEdgeNo(int edgeNo) {
        this.edgeNo = edgeNo;
    }

    public int getEdgeNo() {
        return edgeNo;
    }

    public boolean isIsDigraph() {
        return isDigraph;
    }

    public void setIsDigraph(boolean isDigraph) {
        this.isDigraph = isDigraph;
    }

    
    public void print(Vertex[] adjacencylist) {
        for (int i = 0; i < adjacencylist.length; i++) {
            Vertex source = adjacencylist[i];
            System.out.print("[" + source.getLabel() + "]  ");
            LinkedList<Edge> List = source.getAdjList();
            for (int j = 0; j < List.size(); j++) {
                System.out.print(List.get(j).getTarget().getLabel() + " ... w= " + List.get(j).getWeight() + "   ");
            }
            System.out.println("");
        }
        
    }
      
    public Edge getEdge(int source, int target) {
        for (int j = 0; j < this.getEdgeNo(); j++) {
            Edge e = this.getEdgeList().get(j);
            if (e.getSource().getLabel() == source && e.getTarget().getLabel() == target || e.getSource().getLabel() == target && e.getTarget().getLabel() == source) {
                return e;
            }
        }
        return null;
    }
    
    
    public LinkedList<Edge> getEdgeList() {
        return this.edge;
    }
    public Edge getEdge(int W) {
        for (int j = 0; j < this.getEdgeList().size(); j++) {
            Edge e = this.getEdgeList().get(j);
            if (e.getWeight() == W) {
                return e;
            }
        }
        return null;
    }
    

}
