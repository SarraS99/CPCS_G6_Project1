/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GraphFrameWork;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.PriorityQueue;

/**
 *
 * @author maha2
 */
public class PQPrimAlg extends MSTAlgorithm {
    
    
    int Cost = 0;

    public PQPrimAlg(graph g) {
        super(g);

    }

    public String displayResultingMST(graph g, int choice) {
  
        //to calculate time of the algorithm 
        Long Start = System.nanoTime();
       
        Long End;
    

        //1- We keep track of vertices included in MST in a separate boolean array inMST[]. and Vertices and parents arrays
        Boolean[] inMST = new Boolean[g.getVerticesNo()];//This array is required to make sure that an already considered vertex is not included in pq again.
        Vertex[] Vertices = new Vertex[g.getVerticesNo()];
        int parents[] = new int[g.getVerticesNo()];

        //2- loop to initialize the Vertices list
        for (int i = 0; i < g.getVerticesNo(); i++) {
            Vertices[i] = new Vertex();
        }
        //3- Initialize keys of all vertices as infinite and  parent of every vertex as -1.
        for (int i = 0; i < g.getVerticesNo(); i++) {
            inMST[i] = false;
            Vertices[i].setKey(Integer.MAX_VALUE);
            Vertices[i].setLabel(i);
            parents[i] = -1;

        }
     
        //4- create the pq and Insert source vertex into pq and make its key as 0 then insert the rest
        PriorityQueue<Vertex> queue = new PriorityQueue<>(Comparator.comparingInt(o -> o.getKey()));
        inMST[0] = true;

        Vertices[0].setKey(0);

        for (int i = 0; i < g.getVerticesNo(); i++) {
            queue.add(Vertices[i]);
        }

        //5- While either pq doesn't become empty ,Extract minimum key vertex from pq, Include it in inMST 
        while (!queue.isEmpty()) {
            Vertex First = queue.poll();
            inMST[First.getLabel()] = true;
            
            //6-  Loop through all adjacent of the first and do following for every vertex 
            
            LinkedList<Edge> AL = g.vertices[First.getLabel()].getAdjList();
            for (int i = 0; i < AL.size(); i++) {
                Vertex target = AL.get(i).Target; // v
                int tempWt = AL.get(i).weight; // v - u weight
                
                //if the vertex is not in already in the mst and  the key value of the adj vertex is larger
                
                if (inMST[target.label] == false && Vertices[target.getLabel()].getKey() > tempWt) {
                    //to update the key:
                    queue.remove(Vertices[target.getLabel()]);
                    Vertices[target.getLabel()].setKey(tempWt);
                    queue.add(Vertices[target.getLabel()]);
                    parents[target.label] = First.getLabel();
                }// end if 
            }//end for
            
        }

        for (int i = 0; i < g.getVerticesNo(); i++) {
            Vertex [] v = g.getVertices();
            LinkedList<Edge> edge = v[i].getAdjList();
            for (int j = 0; j < edge.size(); j++) {
                if (edge.get(j).getSource().getLabel() == i && edge.get(j).getTarget().getLabel() == parents[i]) {
                    super.getMSTresultList().add(edge.get(j));                  
                }//end if 
            }//end 
        }//end for 
    
        //loop to sum the cost of the tree
        for (int i = 0; i < super.getMSTresultList().size(); i++) {
            Cost += super.MSTresultList.get(i).getWeight();
        }//end for

        End = System.currentTimeMillis();
        int ExcutionTime = (int) (End - Start);
       if (choice == 1) {
            System.out.println("The road map (minimum spanning tree) generated  Priority-queue Prim is as\n"
                    + "follows:\n");
            for (int j = 0; j < super.MSTresultList.size() - 1; j++) {

                System.out.println("House name " + (char) (super.getMSTresultList().get(j).getSource().getLabel()+65) + " "
                        + "– House name " + (char)(super.getMSTresultList().get(j).getTarget().getLabel()+65) + ": road name:" + " road x" + super.getMSTresultList().get(j).getTarget().getLabel()
                        + " road size: " + super.getMSTresultList().get(j).weight * 3);
            }
            System.out.println("\"The cost of designed roads: \"" + this.Cost);

        } else {
            //printing the cost and the running time 
            System.out.println("The Cost Of Minimum Spanning Tree is: " + this.Cost);

            double Excuteiontime = (double) (End - Start);
            System.out.println("The Time For Executing Kruskal Algorithm is: " + Excuteiontime);
        }
        return "";

    }

}
