
package GraphFrameWork;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 *
 * @author maha2
 */
public class Vertex {

     int label;
     

     boolean isVisited;


     int parent = -1;
     
     
     
    private int Key;  
   
    
     LinkedList<Edge> adjList;

    
    int rank = 0;
    //===============================

    public Vertex() {
        adjList= new LinkedList<Edge>();
    }


    public Vertex(int label){
        this.label = label;
        this.isVisited = false;
       adjList= new LinkedList<Edge>();
    }

    public Vertex(int label, boolean isVisited) {
        this.label = label;
        this.isVisited = isVisited;
        adjList= new LinkedList<>();
    }


    public int getLabel() {
        return label;
    }

    public boolean isIsVisited() {
        return isVisited;
    }


    public int getKey() {
        return Key;
    }

    public void setLabel(int label) {
        this.label = label;
    }

    public void setIsVisited(boolean isVisited) {
        this.isVisited = isVisited;
    }


    public void setKey(int Key) {
        this.Key = Key;
    }

    public  LinkedList<Edge> getAdjList() {
        return adjList;
    }

    public void setAdjList(LinkedList<Edge> adjList) {
        this.adjList = adjList;
    }
    
    
    public void displayInfo() {}
    
    
}
