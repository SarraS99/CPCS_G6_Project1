/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GraphFrameWork;

import java.util.ArrayList;

/**
 *
 * @author maha2
 */
public class Edge implements Comparable<Edge> {

     int weight;

     Vertex parent;

     Vertex Source;

     Vertex Target;
     
    static ArrayList<Edge> edgeslist = new ArrayList<Edge>();
    

//=========================================    
 public Edge(){}

    public Edge(Vertex Source, Vertex Target, int weight) {
        this.weight = weight;
        this.Source = Source;
        this.Target = Target;
    }

    public Edge(Vertex parent, int weight) {
        this.weight = weight;
        this.parent = parent;
    }

    public Edge(Vertex t) {
        this.weight = 0;
        this.Source = t;
        this.Target = t;
        this.parent = t;
    }

    public int getWeight() {
        return weight;
    }

    public Vertex getParent() {
        return parent;
    }

    public Vertex getSource() {
        return Source;
    }

    public Vertex getTarget() {
        return Target;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public void setParent(Vertex parent) {
        this.parent = parent;
    }

    public void setSource(Vertex Source) {
        this.Source = Source;
    }

    public void setTarget(Vertex Target) {
        this.Target = Target;
    }
    @Override
    public String toString() {

        return (Target.label + "(" + Source.label + "," + weight + ") ");
    }

    @Override
    public int compareTo(Edge o) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

      public void displayInfo() {}
}
